package quiz;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

/** The screen where the user answers questions one by one. */
public class QuizPanel extends JPanel {
    private final MainFrame frame;
    private final String player;
    private final String category;
    private final List<Question> questions;
    private final int secondsPerQuestion;
    private final int[] answers;

    private int current = 0;
    private int remaining;
    private final Timer timer;

    private final JLabel progressLabel = new JLabel();
    private final JLabel timerLabel = new JLabel("", JLabel.RIGHT);
    private final JProgressBar progressBar = new JProgressBar();
    private final JTextArea questionArea = new JTextArea(3, 40);
    private final JRadioButton[] optionButtons = new JRadioButton[4];
    private final ButtonGroup group = new ButtonGroup();
    private final JButton nextButton = new JButton("Next");

    public QuizPanel(MainFrame frame, String player, String category, List<Question> questions, int secondsPerQuestion) {
        this.frame = frame;
        this.player = player;
        this.category = category;
        this.questions = questions;
        this.secondsPerQuestion = secondsPerQuestion;
        this.answers = new int[questions.size()];
        Arrays.fill(answers, -1);

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        // top: progress + timer
        progressLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        timerLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        progressBar.setMaximum(questions.size());
        JPanel top = new JPanel(new BorderLayout(10, 6));
        top.add(progressLabel, BorderLayout.WEST);
        top.add(timerLabel, BorderLayout.EAST);
        top.add(progressBar, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH);

        // centre: question + options
        questionArea.setEditable(false);
        questionArea.setLineWrap(true);
        questionArea.setWrapStyleWord(true);
        questionArea.setFont(new Font("SansSerif", Font.BOLD, 20));
        questionArea.setOpaque(false);
        questionArea.setBorder(BorderFactory.createEmptyBorder(10, 0, 15, 0));

        JPanel options = new JPanel(new java.awt.GridLayout(0, 1, 0, 10));
        for (int i = 0; i < optionButtons.length; i++) {
            optionButtons[i] = new JRadioButton();
            optionButtons[i].setFont(new Font("SansSerif", Font.PLAIN, 16));
            group.add(optionButtons[i]);
            options.add(optionButtons[i]);
        }
        JPanel centre = new JPanel(new BorderLayout());
        centre.add(questionArea, BorderLayout.NORTH);
        centre.add(options, BorderLayout.CENTER);
        add(centre, BorderLayout.CENTER);

        // bottom: quit + next
        JButton quit = new JButton("Quit Quiz");
        quit.addActionListener(e -> onQuit());
        nextButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        nextButton.addActionListener(e -> onNext());
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.add(quit, BorderLayout.WEST);
        bottom.add(nextButton, BorderLayout.EAST);
        add(bottom, BorderLayout.SOUTH);

        timer = new Timer(1000, e -> onTick());
        loadQuestion();
    }

    private void loadQuestion() {
        Question q = questions.get(current);
        progressLabel.setText("Question " + (current + 1) + " of " + questions.size() + "   |   " + q.getCategory());
        progressBar.setValue(current);
        questionArea.setText(q.getText());
        group.clearSelection();
        for (int i = 0; i < optionButtons.length; i++) {
            if (i < q.getOptions().size()) {
                optionButtons[i].setText((char) ('A' + i) + ".  " + q.getOptions().get(i));
                optionButtons[i].setVisible(true);
            } else {
                optionButtons[i].setVisible(false);
            }
        }
        nextButton.setText(current == questions.size() - 1 ? "Finish" : "Next");

        if (secondsPerQuestion > 0) {
            remaining = secondsPerQuestion;
            updateTimerLabel();
            timer.restart();
        } else {
            timerLabel.setText("");
        }
    }

    private void onTick() {
        remaining--;
        updateTimerLabel();
        if (remaining <= 0) {
            advance(); // time is up: move on (unanswered stays -1 unless something was selected)
        }
    }

    private void updateTimerLabel() {
        timerLabel.setText("Time left: " + remaining + "s");
        timerLabel.setForeground(remaining <= 5 ? Color.RED : Color.DARK_GRAY);
    }

    private void onNext() {
        advance();
    }

    private void advance() {
        timer.stop();
        answers[current] = selectedIndex();
        if (current == questions.size() - 1) {
            finish();
        } else {
            current++;
            loadQuestion();
        }
    }

    private int selectedIndex() {
        for (int i = 0; i < optionButtons.length; i++) {
            if (optionButtons[i].isSelected()) return i;
        }
        return -1;
    }

    private void onQuit() {
        timer.stop();
        int choice = JOptionPane.showConfirmDialog(this, "Quit this quiz? Your progress will be lost.",
                "Quit", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            frame.showHome();
        } else if (secondsPerQuestion > 0) {
            timer.start();
        }
    }

    private void finish() {
        int score = 0;
        StringBuilder review = new StringBuilder();
        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i);
            boolean correct = answers[i] == q.getCorrectIndex();
            if (correct) score++;
            review.append(i + 1).append(". ").append(q.getText()).append('\n');
            review.append("   Your answer   : ")
                  .append(answers[i] < 0 ? "(no answer)" : q.getOptions().get(answers[i])).append('\n');
            review.append("   Correct answer: ").append(q.getCorrectAnswer())
                  .append(correct ? "   [correct]" : "   [wrong]").append("\n\n");
        }
        String date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        QuizResult result = new QuizResult(player, category, score, questions.size(), date);
        try {
            frame.resultStore.add(result);
        } catch (Exception e) {
            frame.error("Could not save your result", e);
        }
        frame.showResult(result, review.toString(),
                () -> frame.startQuiz(player, category, questions.size(), secondsPerQuestion));
    }
}
