package quiz;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Main window. Switches between screens using a CardLayout. */
public class MainFrame extends JFrame {
    private static final String HOME = "home";
    private static final String QUIZ = "quiz";
    private static final String RESULT = "result";
    private static final String MANAGE = "manage";
    private static final String BOARD = "board";

    private final CardLayout cards = new CardLayout();
    private final JPanel root = new JPanel(cards);

    final QuestionStore questionStore;
    final ResultStore resultStore;

    private final HomePanel home;
    private final ManagePanel manage;
    private final LeaderboardPanel board;
    private JPanel quizPanel;
    private JPanel resultPanel;

    public MainFrame(QuestionStore questionStore, ResultStore resultStore) {
        super("Online Quiz Application");
        this.questionStore = questionStore;
        this.resultStore = resultStore;

        home = new HomePanel(this);
        manage = new ManagePanel(this);
        board = new LeaderboardPanel(this);
        root.add(home, HOME);
        root.add(manage, MANAGE);
        root.add(board, BOARD);

        setContentPane(root);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(760, 560));
        setSize(860, 620);
        setLocationRelativeTo(null);
        showHome();
    }

    public void showHome() {
        home.refresh();
        cards.show(root, HOME);
    }

    public void showManage() {
        manage.refresh();
        cards.show(root, MANAGE);
    }

    public void showLeaderboard() {
        board.refresh();
        cards.show(root, BOARD);
    }

    /** Loads questions, filters by category, shuffles, and opens the quiz screen. */
    public void startQuiz(String player, String category, int count, int secondsPerQuestion) {
        try {
            List<Question> all = questionStore.load();
            List<Question> pool = new ArrayList<>();
            for (Question q : all) {
                if (category.equals(HomePanel.ALL_CATEGORIES) || q.getCategory().equals(category)) {
                    pool.add(q);
                }
            }
            if (pool.isEmpty()) {
                JOptionPane.showMessageDialog(this, "There are no questions in this category yet.\n"
                        + "Add some from 'Manage Questions'.", "No questions", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            Collections.shuffle(pool);
            List<Question> chosen = new ArrayList<>(pool.subList(0, Math.min(count, pool.size())));

            if (quizPanel != null) root.remove(quizPanel);
            quizPanel = new QuizPanel(this, player, category, chosen, secondsPerQuestion);
            root.add(quizPanel, QUIZ);
            cards.show(root, QUIZ);
        } catch (Exception e) {
            error("Could not load questions", e);
        }
    }

    public void showResult(QuizResult result, String review, Runnable retry) {
        if (resultPanel != null) root.remove(resultPanel);
        resultPanel = new ResultPanel(this, result, review, retry);
        root.add(resultPanel, RESULT);
        cards.show(root, RESULT);
    }

    void error(String message, Exception e) {
        JOptionPane.showMessageDialog(this, message + ":\n" + e, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
