package quiz;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.nio.file.Path;
import java.nio.file.Paths;

/** Application entry point. Run this class. */
public class Main {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // fall back to the default look and feel
        }
        SwingUtilities.invokeLater(() -> {
            try {
                Path dataDir = Paths.get("data");
                QuestionStore questions = new QuestionStore(dataDir.resolve("questions.xml"));
                ResultStore results = new ResultStore(dataDir.resolve("results.xml"));
                questions.seedIfMissing();
                new MainFrame(questions, results).setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Could not start the application:\n" + e,
                        "Startup error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
