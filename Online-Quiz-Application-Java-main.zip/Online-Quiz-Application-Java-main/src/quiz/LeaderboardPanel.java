package quiz;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Font;
import java.util.Comparator;
import java.util.List;

/** Shows all saved results, best score first. */
public class LeaderboardPanel extends JPanel {
    private final MainFrame frame;
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"Rank", "Player", "Category", "Score", "Percent", "Date"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };

    public LeaderboardPanel(MainFrame frame) {
        this.frame = frame;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        JLabel title = new JLabel("Leaderboard");
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        add(title, BorderLayout.NORTH);

        JTable table = new JTable(model);
        table.setRowHeight(24);
        table.getColumnModel().getColumn(0).setMaxWidth(50);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton clear = new JButton("Clear Results");
        JButton back = new JButton("Back");
        clear.addActionListener(e -> onClear());
        back.addActionListener(e -> frame.showHome());
        JPanel buttons = new JPanel();
        buttons.add(clear);
        buttons.add(back);
        add(buttons, BorderLayout.SOUTH);
    }

    public void refresh() {
        model.setRowCount(0);
        try {
            List<QuizResult> results = frame.resultStore.load();
            results.sort(Comparator.comparingInt(QuizResult::percent).reversed()
                    .thenComparing(QuizResult::date, Comparator.reverseOrder()));
            int rank = 1;
            for (QuizResult r : results) {
                model.addRow(new Object[]{rank++, r.player(), r.category(),
                        r.score() + " / " + r.total(), r.percent() + "%", r.date()});
            }
        } catch (Exception e) {
            frame.error("Could not read results", e);
        }
    }

    private void onClear() {
        int choice = JOptionPane.showConfirmDialog(this, "Delete all saved results?",
                "Clear Results", JOptionPane.YES_NO_OPTION);
        if (choice != JOptionPane.YES_OPTION) return;
        try {
            frame.resultStore.clear();
        } catch (Exception e) {
            frame.error("Could not clear results", e);
        }
        refresh();
    }
}
