# Online Quiz Application (100% Java)

A desktop quiz platform written **entirely in Java** (no HTML, JSP, JavaScript, SQL or any other language).
Questions are stored in an **XML file**, read and written with the Java standard library.

## Features

- Take a quiz: choose your name, category, number of questions and an optional timer per question
- Question order is shuffled every attempt
- Instant score, percentage and a full review (your answer vs. correct answer)
- Create, edit and delete questions from inside the app (**Manage Questions**)
- Leaderboard of all attempts, best score first
- Data saved in XML: `data/questions.xml` and `data/results.xml`
  (created automatically on first run, with 13 sample questions)

## Requirements

| Item | Needed |
|---|---|
| **JDK** | **JDK 17 or newer** (17 LTS or 21 LTS recommended). A JRE alone is not enough, you need the JDK to compile. |
| **External libraries** | **None.** Only the JDK is used (Swing for the UI, `javax.xml` / `org.w3c.dom` for XML). |
| **Build tool** | None (no Maven/Gradle/Tomcat). |
| **Editor** | VS Code with the **Extension Pack for Java** (Microsoft). |

Download a JDK from https://adoptium.net (Temurin) or https://www.oracle.com/java/technologies/downloads/.
Check your install:

```
java -version
javac -version
```
Both must show version 17 or higher.

## Project structure

```
OnlineQuizApp/
├── README.md
└── src/
    └── quiz/
        ├── Main.java             <- run this
        ├── MainFrame.java        main window, switches screens
        ├── HomePanel.java        start screen
        ├── QuizPanel.java        question screen + timer
        ├── ResultPanel.java      score and review
        ├── ManagePanel.java      add / edit / delete questions
        ├── QuestionDialog.java   add/edit question form
        ├── LeaderboardPanel.java results table
        ├── Question.java         question model
        ├── QuizResult.java       result model
        ├── QuestionStore.java    reads/writes questions.xml
        └── ResultStore.java      reads/writes results.xml
```

## How to run in VS Code

1. Install a **JDK 17+** (see above) and restart VS Code.
2. In VS Code, open the **Extensions** view and install **Extension Pack for Java**.
3. Unzip the project, then **File > Open Folder...** and choose the `OnlineQuizApp` folder
   (open the folder itself, not just a file inside it).
4. Wait for the Java extension to finish loading (bottom-right status bar).
5. Open `src/quiz/Main.java`.
6. Click **Run** above `public static void main` (or press **F5**).
   The quiz window opens.

On first run a `data/` folder appears in the project root with `questions.xml`.

## How to run from the terminal (optional)

Open a terminal inside the `OnlineQuizApp` folder.

**Windows (PowerShell / CMD):**
```
mkdir out
javac -d out src\quiz\*.java
java -cp out quiz.Main
```

**macOS / Linux:**
```
mkdir -p out
javac -d out src/quiz/*.java
java -cp out quiz.Main
```

Always run from the project root so the `data/` folder is created in the right place.

## How to use

1. **Home:** enter your name, pick a category, number of questions and seconds per question (0 = no limit), then **Start Quiz**.
2. **Quiz:** select an answer and press **Next** (the last question shows **Finish**). When the timer hits 0 the app moves on automatically.
3. **Result:** see your score and the review. Results are saved automatically.
4. **Manage Questions:** **Add**, **Edit** or **Delete** questions. Changes are saved straight to `data/questions.xml`.
5. **Leaderboard:** view all attempts; **Clear Results** wipes them.

## XML format

`data/questions.xml` (you can also edit it by hand while the app is closed):

```xml
<quiz>
  <question category="Java" correct="1" id="q1">
    <text>Which keyword is used to inherit a class in Java?</text>
    <options>
      <option>implements</option>
      <option>extends</option>
      <option>inherits</option>
      <option>super</option>
    </options>
  </question>
</quiz>
```

`correct` is the zero-based index of the right option (0 = A, 1 = B, 2 = C, 3 = D).
To reset to the sample questions, delete `data/questions.xml` and start the app again.

## Troubleshooting

| Problem | Fix |
|---|---|
| `javac` is not recognized | Install a JDK (not just a JRE) and add it to PATH, or set `JAVA_HOME`. |
| VS Code shows no Run button | Install **Extension Pack for Java** and open the `OnlineQuizApp` folder itself. |
| "Unsupported class version" error | Your JDK is older than 17. Install JDK 17 or newer. |
| Window does not appear on a remote/headless machine | Swing needs a graphical desktop; run it on a normal PC. |
| Questions not loading | Make sure `data/questions.xml` is valid XML, or delete it to regenerate. |

## Note on the original spec

The original project idea used Servlets and JSP. Those need a web server (Tomcat) and HTML pages,
which are not Java. To keep the project 100% Java with no extra setup, this version is a Swing desktop
application that keeps the same goal (online quiz creation and participation) and the same XML storage.
