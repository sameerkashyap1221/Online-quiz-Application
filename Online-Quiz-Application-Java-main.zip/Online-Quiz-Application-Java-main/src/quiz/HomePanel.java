package quiz;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.Set;
import java.util.TreeSet;

/** Start screen: choose name, category, number of questions and timer. */
public class HomePanel extends JPanel {
    static final String ALL_CATEGORIES = "All categories";

    private final MainFrame frame;
    private final JTextField nameField = new JTextField(18);
    private final JComboBox<String> categoryBox = new JComboBox<>();
    private final JSpinner countSpinner = new JSpinner(new SpinnerNumberModel(5, 1, 50, 1));
    private final JSpinner timerSpinner = new JSpinner(new SpinnerNumberModel(20, 0, 300, 5));

    public HomePanel(MainFrame frame) {
        this.frame = frame;
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        JLabel title = new JLabel("Online Quiz Application", JLabel.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 30));
        JLabel subtitle = new JLabel("Test your knowledge. Create and take quizzes.", JLabel.CENTER);
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 14));

        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        title.setAlignmentX(CENTER_ALIGNMENT);
        subtitle.setAlignmentX(CENTER_ALIGNMENT);
        header.add(title);
        header.add(Box.createVerticalStrut(6));
        header.add(subtitle);
        header.add(Box.createVerticalStrut(25));
        add(header, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.anchor = GridBagConstraints.WEST;
        addRow(form, c, 0, "Your name:", nameField);
        addRow(form, c, 1, "Category:", categoryBox);
        addRow(form, c, 2, "Number of questions:", countSpinner);
        addRow(form, c, 3, "Seconds per question (0 = no limit):", timerSpinner);

        JButton start = new JButton("Start Quiz");
        start.setFont(new Font("SansSerif", Font.BOLD, 16));
        start.addActionListener(e -> onStart());
        c.gridx = 0; c.gridy = 4; c.gridwidth = 2; c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(18, 8, 8, 8);
        form.add(start, c);

        JPanel center = new JPanel();
        center.add(form);
        add(center, BorderLayout.CENTER);

        JButton manage = new JButton("Manage Questions");
        JButton board = new JButton("Leaderboard");
        JButton exit = new JButton("Exit");
        manage.addActionListener(e -> frame.showManage());
        board.addActionListener(e -> frame.showLeaderboard());
        exit.addActionListener(e -> System.exit(0));
        JPanel bottom = new JPanel();
        bottom.add(manage);
        bottom.add(board);
        bottom.add(exit);
        add(bottom, BorderLayout.SOUTH);

        nameField.addActionListener(e -> onStart());
    }

    private void addRow(JPanel form, GridBagConstraints c, int row, String label, java.awt.Component field) {
        c.gridx = 0; c.gridy = row; c.gridwidth = 1; c.fill = GridBagConstraints.NONE;
        form.add(new JLabel(label), c);
        c.gridx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        if (field instanceof JSpinner) ((JSpinner) field).setPreferredSize(new Dimension(80, 26));
        form.add(field, c);
    }

    /** Reloads the category list from the XML file. */
    public void refresh() {
        Object selected = categoryBox.getSelectedItem();
        categoryBox.removeAllItems();
        categoryBox.addItem(ALL_CATEGORIES);
        try {
            Set<String> cats = new TreeSet<>();
            for (Question q : frame.questionStore.load()) cats.add(q.getCategory());
            for (String cat : cats) categoryBox.addItem(cat);
        } catch (Exception e) {
            frame.error("Could not read questions", e);
        }
        if (selected != null) categoryBox.setSelectedItem(selected);
    }

    private void onStart() {
        String name = nameField.getText().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter your name first.");
            nameField.requestFocus();
            return;
        }
        String category = (String) categoryBox.getSelectedItem();
        if (category == null) category = ALL_CATEGORIES;
        frame.startQuiz(name, category, (Integer) countSpinner.getValue(), (Integer) timerSpinner.getValue());
    }
}
