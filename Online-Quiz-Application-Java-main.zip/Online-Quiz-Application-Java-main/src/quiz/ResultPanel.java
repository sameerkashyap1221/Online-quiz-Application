package quiz;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import java.awt.Font;

/** Shows the score and a question-by-question review. */
public class ResultPanel extends JPanel {
    public ResultPanel(MainFrame frame, QuizResult result, String review, Runnable retry) {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        String message;
        int p = result.percent();
        if (p >= 90) message = "Excellent work!";
        else if (p >= 70) message = "Good job!";
        else if (p >= 50) message = "Not bad, keep practising.";
        else message = "Keep learning, you will get there!";

        JLabel title = new JLabel(result.player() + ", you scored " + result.score() + " / " + result.total()
                + "  (" + p + "%)", JLabel.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        JLabel msg = new JLabel(message, JLabel.CENTER);
        msg.setFont(new Font("SansSerif", Font.PLAIN, 16));
        JPanel top = new JPanel(new BorderLayout(0, 6));
        top.add(title, BorderLayout.NORTH);
        top.add(msg, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH);

        JTextArea area = new JTextArea(review);
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setFont(new Font("Monospaced", Font.PLAIN, 13));
        area.setCaretPosition(0);
        add(new JScrollPane(area), BorderLayout.CENTER);

        JButton again = new JButton("Try Again");
        JButton home = new JButton("Home");
        JButton board = new JButton("Leaderboard");
        again.addActionListener(e -> retry.run());
        home.addActionListener(e -> frame.showHome());
        board.addActionListener(e -> frame.showLeaderboard());
        JPanel bottom = new JPanel();
        bottom.add(again);
        bottom.add(board);
        bottom.add(home);
        add(bottom, BorderLayout.SOUTH);
    }
}
