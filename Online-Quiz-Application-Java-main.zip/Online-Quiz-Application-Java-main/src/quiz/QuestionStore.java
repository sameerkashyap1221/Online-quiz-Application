package quiz;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Reads and writes questions to an XML file using the JDK's built-in DOM API. */
public class QuestionStore {
    private final Path file;

    public QuestionStore(Path file) {
        this.file = file;
    }

    public Path getFile() {
        return file;
    }

    /** Creates data/questions.xml with sample questions the first time the app runs. */
    public void seedIfMissing() throws Exception {
        if (Files.exists(file)) return;
        save(defaultQuestions());
    }

    public List<Question> load() throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        factory.setXIncludeAware(false);
        factory.setExpandEntityReferences(false);
        Document doc = factory.newDocumentBuilder().parse(file.toFile());

        List<Question> result = new ArrayList<>();
        NodeList nodes = doc.getElementsByTagName("question");
        for (int i = 0; i < nodes.getLength(); i++) {
            Element q = (Element) nodes.item(i);
            String text = q.getElementsByTagName("text").item(0).getTextContent().trim();
            List<String> options = new ArrayList<>();
            NodeList opts = q.getElementsByTagName("option");
            for (int j = 0; j < opts.getLength(); j++) {
                options.add(opts.item(j).getTextContent().trim());
            }
            int correct = Integer.parseInt(q.getAttribute("correct"));
            if (options.size() < 2 || correct < 0 || correct >= options.size()) continue; // skip bad entries
            result.add(new Question(q.getAttribute("id"), q.getAttribute("category"), text, options, correct));
        }
        return result;
    }

    public void save(List<Question> questions) throws Exception {
        Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        Element root = doc.createElement("quiz");
        doc.appendChild(root);
        for (Question q : questions) {
            Element e = doc.createElement("question");
            e.setAttribute("id", q.getId());
            e.setAttribute("category", q.getCategory());
            e.setAttribute("correct", String.valueOf(q.getCorrectIndex()));
            Element text = doc.createElement("text");
            text.setTextContent(q.getText());
            e.appendChild(text);
            Element options = doc.createElement("options");
            for (String o : q.getOptions()) {
                Element opt = doc.createElement("option");
                opt.setTextContent(o);
                options.appendChild(opt);
            }
            e.appendChild(options);
            root.appendChild(e);
        }
        write(doc, file);
    }

    static void write(Document doc, Path target) throws Exception {
        Path parent = target.toAbsolutePath().getParent();
        if (parent != null) Files.createDirectories(parent);
        Transformer t = TransformerFactory.newInstance().newTransformer();
        t.setOutputProperty(OutputKeys.INDENT, "yes");
        t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
        try (OutputStream out = Files.newOutputStream(target)) {
            t.transform(new DOMSource(doc), new StreamResult(out));
        }
    }

    private static Question q(String id, String category, String text, int correct, String... options) {
        return new Question(id, category, text, Arrays.asList(options), correct);
    }

    private static List<Question> defaultQuestions() {
        List<Question> l = new ArrayList<>();
        l.add(q("q1", "Java", "Which keyword is used to inherit a class in Java?", 1,
                "implements", "extends", "inherits", "super"));
        l.add(q("q2", "Java", "Which method is the entry point of a Java program?", 2,
                "start()", "run()", "public static void main(String[] args)", "init()"));
        l.add(q("q3", "Java", "What is the default value of an int instance variable?", 0,
                "0", "null", "1", "undefined"));
        l.add(q("q4", "Java", "Which collection does NOT allow duplicate elements?", 2,
                "ArrayList", "LinkedList", "HashSet", "Vector"));
        l.add(q("q5", "Java", "Which keyword prevents a method from being overridden?", 3,
                "static", "abstract", "private", "final"));
        l.add(q("q6", "Java", "How many bits does an int occupy in Java?", 2,
                "8", "16", "32", "64"));
        l.add(q("q7", "Servlets & JSP", "Which HttpServlet method handles an HTTP GET request?", 1,
                "service()", "doGet()", "getRequest()", "handleGet()"));
        l.add(q("q8", "Servlets & JSP", "A JSP page is translated and compiled into a...", 0,
                "Servlet", "Applet", "Jar file", "XML document"));
        l.add(q("q9", "Servlets & JSP", "Which file is the deployment descriptor of a Java web application?", 3,
                "pom.xml", "build.xml", "config.xml", "web.xml"));
        l.add(q("q10", "Servlets & JSP", "Which interface represents a user session in the Servlet API?", 1,
                "HttpCookie", "HttpSession", "ServletContext", "HttpRequest"));
        l.add(q("q11", "XML", "What does XML stand for?", 2,
                "Extra Markup Language", "Extended Mark Language", "eXtensible Markup Language", "Executable Markup Language"));
        l.add(q("q12", "XML", "Which Java XML API loads the whole document as a tree in memory?", 1,
                "SAX", "DOM", "StAX", "JAXP-Stream"));
        l.add(q("q13", "General Knowledge", "What is the capital of India?", 0,
                "New Delhi", "Mumbai", "Kolkata", "Chandigarh"));
        return l;
    }
}
