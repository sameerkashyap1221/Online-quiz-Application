package quiz;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/** Create, edit and delete questions (saved to data/questions.xml). */
public class ManagePanel extends JPanel {
    private final MainFrame frame;
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"#", "Category", "Question", "Correct answer"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);
    private List<Question> questions = new ArrayList<>();

    public ManagePanel(MainFrame frame) {
        this.frame = frame;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        JLabel title = new JLabel("Manage Questions");
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        add(title, BorderLayout.NORTH);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setRowHeight(24);
        table.getColumnModel().getColumn(0).setMaxWidth(40);
        table.getColumnModel().getColumn(1).setPreferredWidth(110);
        table.getColumnModel().getColumn(2).setPreferredWidth(380);
        table.getColumnModel().getColumn(3).setPreferredWidth(160);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton add = new JButton("Add");
        JButton edit = new JButton("Edit");
        JButton delete = new JButton("Delete");
        JButton back = new JButton("Back");
        add.addActionListener(e -> onAdd());
        edit.addActionListener(e -> onEdit());
        delete.addActionListener(e -> onDelete());
        back.addActionListener(e -> frame.showHome());
        JPanel buttons = new JPanel();
        buttons.add(add);
        buttons.add(edit);
        buttons.add(delete);
        buttons.add(back);
        add(buttons, BorderLayout.SOUTH);
    }

    public void refresh() {
        try {
            questions = frame.questionStore.load();
        } catch (Exception e) {
            frame.error("Could not read questions", e);
            questions = new ArrayList<>();
        }
        model.setRowCount(0);
        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i);
            model.addRow(new Object[]{i + 1, q.getCategory(), q.getText(), q.getCorrectAnswer()});
        }
    }

    private Set<String> categories() {
        Set<String> cats = new TreeSet<>();
        for (Question q : questions) cats.add(q.getCategory());
        return cats;
    }

    private void onAdd() {
        Question q = QuestionDialog.show(this, null, categories());
        if (q == null) return;
        questions.add(q);
        persist();
    }

    private void onEdit() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a question to edit first.");
            return;
        }
        Question edited = QuestionDialog.show(this, questions.get(row), categories());
        if (edited == null) return;
        questions.set(row, edited);
        persist();
    }

    private void onDelete() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a question to delete first.");
            return;
        }
        int choice = JOptionPane.showConfirmDialog(this, "Delete the selected question?",
                "Delete", JOptionPane.YES_NO_OPTION);
        if (choice != JOptionPane.YES_OPTION) return;
        questions.remove(row);
        persist();
    }

    private void persist() {
        try {
            frame.questionStore.save(questions);
        } catch (Exception e) {
            frame.error("Could not save questions", e);
        }
        refresh();
    }
}
