package quiz;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/** Dialog used to add or edit a question. */
final class QuestionDialog {
    private QuestionDialog() {}

    /** Returns the new/edited question, or null if the user cancelled. */
    static Question show(Component parent, Question existing, Collection<String> categories) {
        JComboBox<String> categoryBox = new JComboBox<>(categories.toArray(new String[0]));
        categoryBox.setEditable(true);
        JTextArea textArea = new JTextArea(3, 30);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        JTextField[] optionFields = new JTextField[4];
        for (int i = 0; i < 4; i++) optionFields[i] = new JTextField(30);
        JComboBox<String> correctBox = new JComboBox<>(new String[]{"A", "B", "C", "D"});

        if (existing != null) {
            categoryBox.setSelectedItem(existing.getCategory());
            textArea.setText(existing.getText());
            for (int i = 0; i < 4 && i < existing.getOptions().size(); i++) {
                optionFields[i].setText(existing.getOptions().get(i));
            }
            correctBox.setSelectedIndex(existing.getCorrectIndex());
        }

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4, 4, 4, 4);
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        int row = 0;
        row = addRow(panel, c, row, "Category:", categoryBox);
        row = addRow(panel, c, row, "Question:", new JScrollPane(textArea));
        for (int i = 0; i < 4; i++) {
            row = addRow(panel, c, row, "Option " + (char) ('A' + i) + ":", optionFields[i]);
        }
        addRow(panel, c, row, "Correct answer:", correctBox);

        while (true) {
            int choice = JOptionPane.showConfirmDialog(parent, panel,
                    existing == null ? "Add Question" : "Edit Question",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (choice != JOptionPane.OK_OPTION) return null;

            String category = String.valueOf(categoryBox.getSelectedItem()).trim();
            String text = textArea.getText().trim();
            List<String> options = new ArrayList<>();
            boolean allFilled = true;
            for (JTextField f : optionFields) {
                String v = f.getText().trim();
                if (v.isEmpty()) allFilled = false;
                options.add(v);
            }
            if (category.isEmpty() || category.equals("null") || text.isEmpty() || !allFilled) {
                JOptionPane.showMessageDialog(parent, "Please fill in the category, the question and all four options.");
                continue;
            }
            String id = existing != null ? existing.getId() : "q" + System.currentTimeMillis();
            return new Question(id, category, text, options, correctBox.getSelectedIndex());
        }
    }

    private static int addRow(JPanel p, GridBagConstraints c, int row, String label, Component field) {
        c.gridx = 0; c.gridy = row; c.weightx = 0;
        p.add(new JLabel(label), c);
        c.gridx = 1; c.weightx = 1;
        p.add(field, c);
        return row + 1;
    }
}
