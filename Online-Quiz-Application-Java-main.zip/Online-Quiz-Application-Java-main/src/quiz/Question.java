package quiz;

import java.util.ArrayList;
import java.util.List;

/** A single multiple-choice question. */
public class Question {
    private final String id;
    private final String category;
    private final String text;
    private final List<String> options;
    private final int correctIndex;

    public Question(String id, String category, String text, List<String> options, int correctIndex) {
        this.id = id;
        this.category = category;
        this.text = text;
        this.options = new ArrayList<>(options);
        this.correctIndex = correctIndex;
    }

    public String getId() { return id; }
    public String getCategory() { return category; }
    public String getText() { return text; }
    public List<String> getOptions() { return options; }
    public int getCorrectIndex() { return correctIndex; }
    public String getCorrectAnswer() { return options.get(correctIndex); }
}
