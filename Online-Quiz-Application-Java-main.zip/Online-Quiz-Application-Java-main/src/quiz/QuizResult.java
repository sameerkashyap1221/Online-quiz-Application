package quiz;

/** One finished quiz attempt (stored in data/results.xml). */
public record QuizResult(String player, String category, int score, int total, String date) {
    public int percent() {
        return total == 0 ? 0 : Math.round(score * 100f / total);
    }
}
