package quiz;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilderFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Stores finished quiz attempts in an XML file (the leaderboard data). */
public class ResultStore {
    private final Path file;

    public ResultStore(Path file) {
        this.file = file;
    }

    public List<QuizResult> load() throws Exception {
        List<QuizResult> list = new ArrayList<>();
        if (!Files.exists(file)) return list;
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        Document doc = factory.newDocumentBuilder().parse(file.toFile());
        NodeList nodes = doc.getElementsByTagName("result");
        for (int i = 0; i < nodes.getLength(); i++) {
            Element e = (Element) nodes.item(i);
            list.add(new QuizResult(
                    e.getAttribute("player"),
                    e.getAttribute("category"),
                    Integer.parseInt(e.getAttribute("score")),
                    Integer.parseInt(e.getAttribute("total")),
                    e.getAttribute("date")));
        }
        return list;
    }

    public void add(QuizResult result) throws Exception {
        List<QuizResult> all = load();
        all.add(result);
        saveAll(all);
    }

    public void clear() throws Exception {
        saveAll(new ArrayList<>());
    }

    private void saveAll(List<QuizResult> all) throws Exception {
        Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        Element root = doc.createElement("results");
        doc.appendChild(root);
        for (QuizResult r : all) {
            Element e = doc.createElement("result");
            e.setAttribute("player", r.player());
            e.setAttribute("category", r.category());
            e.setAttribute("score", String.valueOf(r.score()));
            e.setAttribute("total", String.valueOf(r.total()));
            e.setAttribute("date", r.date());
            root.appendChild(e);
        }
        QuestionStore.write(doc, file);
    }
}
